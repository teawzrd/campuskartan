import React from 'react';

const InfoBox = () => {
   return(
    <div className="menu">
      <br/><br/><br/><br/><br/><br/>
      
      <div>
        Här i denna ruta ska det finns information om
        hur appen används och hjälp. Det ska förklaras vad symboler
        betyder osv
      </div>

    </div>
  );
}

export default InfoBox;