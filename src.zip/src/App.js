import React,{useState} from 'react';
import './App.css';
import {BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

//Tell Webpack which image-files to use.
import TP3 from './temp_kartor/TP.png';
import TP4 from './temp_kartor/TP41.png';
import TP5 from './temp_kartor/TP51.png';

import K1 from './temp_kartor/K101.png';
import K2 from './temp_kartor/K23.png'; //OBS INGÅNG
import K3 from './temp_kartor/BYT_UT_MIG_SNÄLLA.jpg';
import K4 from './temp_kartor/K42.png';
import K5 from './temp_kartor/K501.png';


import overview from './temp_kartor/overview.jpg';

import Tappan from './tappan.js';
import Kakenhus from './kaken.js';
import TopBar from './TopBar.js'


//TODO: LÄGG TILL ALT FÖR ALLA BILDER!

//let myStorage = window.localStorage;
//myStorage.setItem('floor', '3');



function App() {

  let [floor, setFloor] = useState(3);

  const upOrDown = floorIn =>
  {
    setFloor(floorIn);

  }


  return (
  	<div>

  	<TopBar handlefloor={upOrDown}/>



  	//App hanterar endast routern
	  	<Router>
	 		<Switch>

	          <Route exact path="/">
	            <Home />
	          </Route>

	          <Route path="/Täppan">
	            <Tappan floor={floor} />
	          </Route>

	          <Route path="/Kåkenhus">
	            <Kakenhus floor={floor} />
	          </Route>

	        </Switch>
	    </Router>

    </div>
  );
}

function Home() {
//Home-sida, överblicksvy
  return (
    <div>
      <div className = "background">

      	<Link to="/Kåkenhus">
	      	<div style={{backgroundColor: 'green', width: '100px'}}	>
	      		<h1>Kåken</h1>
	      	</div>
	      	<br/>
      	</Link>

      	<Link to="/Täppan">
	      	<div style={{backgroundColor: 'lightgreen', width: '100px'}} >
      			<h1>Täppan</h1>
      		</div>
      		<br/>
      	</Link>




        <img src={overview} className = "background_image"/>
      </div>
    </div>
  );
}






export default App;
