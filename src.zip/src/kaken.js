import React,{useState} from 'react';
import './App.css';

import Buttons from './buttons.js';

import TopBar from './TopBar.js';


//Tell Webpack which image-files to use.
import TP3 from './temp_kartor/TP.png';
import TP4 from './temp_kartor/TP41.png';
import TP5 from './temp_kartor/TP51.png';

import K1 from './temp_kartor/K101.png';
import K2 from './temp_kartor/K23.png'; //OBS INGÅNG
import K3 from './temp_kartor/BYT_UT_MIG_SNÄLLA.jpg';
import K4 from './temp_kartor/K42.png';
import K5 from './temp_kartor/K501.png';


import overview from './temp_kartor/overview.jpg';
import up_button from './symbols/up_arrow.png';
import down_button from './symbols/down_arrow.png';


const Kakenhus = props => {
	//floor = nuvarande våning, initialiseras med 2

	console.log("testing in Kåkenhus: " + props.floor)

	//minsta/högsta våning
	let bottom_floor = 1;
	let top_floor = 5;

	//kontrollerar att våningen finns
	if(props.floor < bottom_floor) {
			props.floor = bottom_floor;
	}

	if(props.floor > top_floor) {
			props.floor = top_floor;
	}



	//Kallar på egen function för knappar samt bakgrund
	if(props.floor == bottom_floor) {
	return (
	<div>
		<div className = "background">
			<img src={K1} className = "background_image"/>
		</div>
    </div>
  	);
	}

	else if(props.floor == 2) {
	return (
	<div>
		<div className = "background">
			<img src={K2} className = "background_image"/>
		</div>
    </div>
  	);
	}

	else if(props.floor == 3){
	return (
	<div>
		<div className = "background">
			<img src={K3} className = "background_image"/>
		</div>
    </div>
    );
	}

    else if(props.floor == 4){
	return (
	<div>
		<div className = "background">
			<img src={K4} className = "background_image"/>
		</div>
    </div>
    );
	}

    else if(props.floor == 5){
	return (
	<div>
		<div className = "background">
			<img src={K5} className = "background_image"/>
		</div>
    </div>
  	);
	}
}




export default Kakenhus;
