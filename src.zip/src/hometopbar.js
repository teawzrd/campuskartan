import React from 'react';
import logo from './symbols/loggo.svg';
import './topbar.css';
import { useState } from "react";  
import { Router, Route, Switch, Link } from "react-router-dom";
import './App.css';
import InfoButton from './symbols/help.svg';
import InfoBox from './infobox.js';

const HomeTopBar = props =>
{
  const [infoBoxIsOpen, setInfoBox] = useState(false);

  const toggleInfoBox = event =>
  {
    if(infoBoxIsOpen)
    {
      setInfoBox(false);
    }
    else if(!infoBoxIsOpen)
    {
      setInfoBox(true);
    }
  };


  return(
    <div>

      <div className="top-bar">
        
        <div id="campuskartan_logo">
          <img src={logo} style={{width:60 + "vw", margin:"auto", marginRight:"3vw"}} />


        <div style={{}} onClick={toggleInfoBox}>
          <img src={InfoButton} style={{width:6 + "vw", marginBottom: "1vw"}} />
        </div>

        </div>
      </div>

      { 
        infoBoxIsOpen 
        && 
        InfoBox() 
      }

    </div>
  );
}


export default HomeTopBar;


/*

*/