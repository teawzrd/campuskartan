import React,{useState} from 'react';
import rooms from './rooms.json';
import './App.css';
import {BrowserRouter as Router, Switch, Route, useParams, Link } from "react-router-dom";

import T3 from './temp_kartor/TP51.png';
import overview from './temp_kartor/overview.jpg';

let showList = true;
var founded = false;

function SearchBar(props) 
{
  //console.log("In SearchBar " +props.selectedR);

  return(
    <div style={  {/*backgroundColor: 'darkgreen'*/} }>
      <SearchFunction building={props} searchFromURL={props.searchFromURL}/>
      
    </div>
  );
}


 
//sökfunktionen
function SearchFunction(props) 
{
  let {room} = useParams();
  //let defaultSearchString = props.searchFromURL;

  if(room == undefined)
  {
    room = "";
  }
 console.log(":::::::::::::::: useParams room = " + room);

  //hanterar sökfunktion
  const [searchString, setSearchString] = useState(room);
  const [placeholder, setPlaceholder] = useState("Sök på sal... ");
  //const [clickedRoom]
console.log("searchString: " + searchString)

  function changeInput(event) 
  {
      setSearchString(event.target.value);
      showList = true;
  }

  function test(room) 
  {
    console.log("test: " + room)
    setSearchString(room); 

    foundRooms = [];
    showList = false;

  }

  //hittar match beroende på sökord
  const match = roomName => 
  {
    if(searchString != undefined)
    {
      const lowerCaseWord = roomName.room.toLowerCase();
      const lowerCaseSearchString = searchString.toLowerCase();

      return lowerCaseWord.indexOf(lowerCaseSearchString) === 0;
    }

  }

  //hittade rum
  var foundRooms = [];
  
 

  if(searchString != "")
  {
    var foundRooms = rooms.filter(match); 


    if(foundRooms.length == 0){
      foundRooms = [0];
      founded = false;
    }
    else{
      founded = true;
      console.log("heeeej");
    }

  } 

/*
  let found = false;

  if((searchString != "") && (foundRooms.length == 0))
  {
    console.log("aAAAAAAAAaaaA");
    found = false;
  }
  else
  {
    found = true;
  }*/
    
  console.log(searchString);
  return(
    <div>
      <div>
        {/*sökruta*/}
          <div className = "searchbar">
            <input type="text" id="searchBox" placeholder={placeholder} value={searchString} onChange={changeInput}/>
          </div>
          
          <div id= "listElement">
          {/*listar sökresultat fint*/}
            

            <div id ="listBox" >
              
                
               { foundRooms.slice(0,5).map(c => (<div onClick={() => test(c.room)}><RoomInfo data={c} state={showList} key={c.room} found={founded} /></div>))  }
              
                
              
            </div>
            

          </div>
      </div>
    </div>
  );
}
// onClick={hideSearchBar}
function RoomInfo(props)
{
  
  if((props.state) && (props.found))
  {
  
    return(
      <Link className = "aa" to = {"/"+ props.data.house + "/" 
      +  props.data.floor + "/" + props.data.room 
      + "/" + props.data.coord.x + "/" + props.data.coord.y}>
      
        <div className="listOverlay">
          {props.data.room}
        </div>
      </Link> 
    );
  } 

  else if((props.state) && (!props.found))
  {
    
    return(<div className="listOverlay2">Hittade inga rum. </div> )
    //return (<div></div>);
  }
  else{
    return(<div></div>);
  }

}


export default SearchBar;


