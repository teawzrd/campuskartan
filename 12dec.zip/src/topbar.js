import React from 'react';
import './topbar.css';
import { useState } from "react";  
import { Router, Route, Switch, Link } from "react-router-dom";
import upButton from './symbols/up_white.svg';
import downButton from './symbols/down_white.svg';
import upButtonGrey from './symbols/up_grey.svg';
import downButtonGrey from './symbols/down_grey.svg';
import homeButton from './symbols/home.svg'; 
import InfoButton from './symbols/help.svg';
import Kakenhus from './kakenhus.js';
import Tappan from './tappan.js';
import InfoBox from './infobox.js';

//Bör ändras så att värdet floor fås från URL och inte sparas som sin egen state
const TopBar = props =>
{
  //console.log("----floorz = " + props.floorFromURL);


  let defaultFloor = parseInt(props.floorFromURL);


  //console.log("yyyyyyyyyy defaultfloor = " + defaultFloor);

  let topFloor; 
  let bottomFloor;


  if(props.building === "Täppan")
  {
    //defaultFloor = 3;
    topFloor = 5;
    bottomFloor = 3
  }

  if(props.building === "Kåkenhus")
  {
    //defaultFloor = 2;
    topFloor = 5;
    bottomFloor = 1;
  }



  const getUpButton = () =>
  {
    if(defaultFloor == topFloor){
      return "up_grey";
    }
    else{
      return "up_white";
    }
  }

  const getDownButton = () =>
  {
    if(defaultFloor == bottomFloor){
      return "down_grey";
    }
    else{
      return "down_white";
    }
  }


  


  const [floor, setFloor] = useState(defaultFloor);



  //ändrar statet floor
  const up = event => 
  {
    if(floor >= topFloor)
    {
      setFloor(topFloor);
      return;
    }

    setFloor(floor + 1);
  }

  //ändrar statet floor
  const down = event => 
  {
    if(floor <= bottomFloor)
    {
      setFloor(bottomFloor);
      return;
    }

    setFloor(floor - 1); 
  }
{/*
  */}
  //returnerar värdet på det floor man klickar sig till
  const toFloor = arg =>
  {
    if(arg === "down")
    {
      if(floor <= bottomFloor)
      {
        return bottomFloor;
      }

      return floor - 1;
    }

    else if(arg === "up")
    {
      if(floor >= topFloor)
      {
        return topFloor;
      }

      return floor + 1;
    }
  }






  //==================================================//
  //==============   InfoBox code   ==================//
  //==================================================//
  const [infoBoxIsOpen, setInfoBox] = useState(false);

  const toggleInfoBox = event =>
  {
    if(infoBoxIsOpen)
    {
      setInfoBox(false);
    }
    else if(!infoBoxIsOpen)
    {
      setInfoBox(true);
    }
  };
  //==================================================//




  return(
    <div>

      <div className="top-bar">


        
        <Link to={"/"} >
          <img src={homeButton} style={{ height:80 }} className="menu-button"/>
        </Link>

        <div>
          <p>{props.building}</p> 
        </div>

        <Link to={"/" + props.building + "/" + toFloor("down") } >
          <div onClick={down}>
            <img src={require('./symbols/' + getDownButton() + '.svg')} style={{ height:25, marginLeft:"5px" }} className="arrow"/>
          </div>
        </Link>

        <div style={{marginRight: "5px"}}>
          <p>{defaultFloor}</p>
        </div>

        <Link to={"/" + props.building + "/" + toFloor("up") } >
          <div onClick={up}>
            <img src={require('./symbols/' + getUpButton() + '.svg')} style={{ height:25, marginRight:"5px" }} className="arrow"/>
          </div>
        </Link>

        <div style={{marginTop: "30px", marginRight: "10px", float: "right"}} onClick={toggleInfoBox}>
          <img src={InfoButton} style={{height:40}} />
        </div>

      </div>


      {/*
        */}
      { 
        infoBoxIsOpen 
        && 
        InfoBox() 
      }
      

    </div>
  );
}


export default TopBar;


/*

*/